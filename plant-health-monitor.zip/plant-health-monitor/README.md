# 🌿 FloraScan AI: Plant Disease Detection & Health Monitoring

[![FastAPI](https://img.shields.io/badge/Backend-FastAPI-009688.svg?style=flat&logo=fastapi)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/Frontend-React%2018%20%2B%20Vite-61DAFB.svg?style=flat&logo=react)](https://react.dev)
[![Tailwind CSS](https://img.shields.io/badge/Styling-Tailwind%20CSS-38B2AC.svg?style=flat&logo=tailwind-css)](https://tailwindcss.com)
[![SQLite](https://img.shields.io/badge/Database-SQLite-003B57.svg?style=flat&logo=sqlite)](https://sqlite.org)
[![Computer Vision](https://img.shields.io/badge/CV-Morphological%20%26%20Spectra-4CAF50.svg)](https://pillow.readthedocs.io)

An end-to-end full-stack platform for automated plant leaf disease diagnosis, health scoring, lesion localization, and treatment recommendation.

---

## 📸 Key Features

1. **Computer Vision Diagnostic Core:**
   - **Disease Classification:** Detects *Healthy Foliage*, *Early Blight (Alternaria solani)*, *Late Blight (Phytophthora infestans)*, *Leaf Rust (Puccinia)*, *Powdery Mildew (Podosphaera / Erysiphe)*, and *Bacterial Leaf Spot (Xanthomonas)*.
   - **Lesion Localization & Bounding Boxes:** Extracts spectral color anomaly masks (chlorosis, necrosis, rust spores, white powdery mycelia) and connected-component bounding boxes with normalized coordinates `[ymin, xmin, ymax, xmax]`.
   - **Interactive Visualizer:** Toggle dynamic SVG bounding boxes over the original leaf photo or inspect the AI multispectral heatmap.

2. **Multispectral Health Status Index (0–100%):**
   - Computes whole-leaf photosynthetic vitality based on lesion surface area, chlorosis ratio, and pathogen severity.
   - Renders animated circular radial health gauges color-coded by stress thresholds (Green: Optimal $\ge 85\%$, Amber: Moderate $60-84\%$, Red: Critical $<60\%$).

3. **Agronomic Actionable Treatment Protocols:**
   - **🌿 Organic Remedies:** Cold-pressed Neem oil, Copper octanoate soap, milk foliar sprays, bio-fungicides (*Bacillus subtilis*), compost teas, cultural pruning.
   - **🧪 Chemical Treatments:** Formulated active ingredients (Chlorothalonil, Mancozeb, Ridomil Gold, Propiconazole, Myclobutanil) with precise dosage, withholding periods, and PPE guidelines.
   - **🛡️ Preventive Measures:** Drip irrigation, 3-year crop rotations, canopy airflow spacing, resistant cultivars.

4. **1-Click Verified Specimen Quick-Tester:**
   - Pre-loaded with high-fidelity realistic specimens (Healthy Tomato, Early Blight, Late Blight, Corn Rust, Powdery Mildew, Bacterial Spot) allowing 1-click test runs without needing camera files.

5. **Chronological Scan Archive & Analytics Dashboard:**
   - Persistent SQLite history database logging all past diagnoses, thumbnails, and treatment protocols.
   - Surveillance analytics tracking total scans, healthy vs. infected ratios, and top disease prevalence.

---

## 🏗️ Architecture & Directory Layout

```
plant-health-monitor/
├── backend/
│   ├── app/
│   │   ├── main.py                  # FastAPI application entrypoint, CORS, static mounts
│   │   ├── core/
│   │   │   ├── config.py            # System configurations & path settings
│   │   │   └── database.py          # SQLite database connection, models, CRUD operations
│   │   ├── api/
│   │   │   └── routes.py            # REST endpoints: /predict, /history, /health-guide, /samples, /stats
│   │   ├── models/
│   │   │   └── schemas.py           # Pydantic schemas for request/response validation
│   │   ├── ml/
│   │   │   ├── detector.py          # CV pipeline, color spaces, lesion localization, bounding boxes
│   │   │   ├── disease_catalog.py   # Comprehensive agronomic database of pathogens & treatments
│   │   │   └── sample_generator.py  # Generates realistic sample leaf images
│   │   └── samples/                 # Sample test leaf images
│   ├── requirements.txt             # Python backend dependencies
│   ├── run.py                       # Backend server launcher
│   └── test_backend.py              # Automated backend test suite
├── frontend/
│   ├── package.json                 # Node.js dependencies (React 18, Vite, Tailwind CSS, Lucide)
│   ├── vite.config.js               # Vite config with backend API proxy
│   ├── tailwind.config.js           # Nature/earthy color palette configuration
│   ├── index.html                   # HTML template
│   └── src/
│       ├── main.jsx                 # React root mount
│       ├── App.jsx                  # Main application orchestrator
│       ├── index.css                # Global Tailwind styles
│       ├── services/
│       │   └── api.js               # API service client
│       └── components/
│           ├── Navbar.jsx           # Top header & live AI status
│           ├── ImageUploader.jsx    # Drag-and-drop uploader with laser scanner animation
│           ├── SampleSelector.jsx   # 1-click test specimen cards
│           ├── DiagnosticCard.jsx   # Master diagnostic report
│           ├── HealthGauge.jsx      # Radial circular SVG health index gauge
│           ├── BoundingBoxViewer.jsx# Interactive canvas bounding box overlay
│           ├── TreatmentGuide.jsx   # Organic & Chemical remedies tabs
│           ├── HistoryList.jsx      # Chronological scan archive & search
│           ├── DiseaseLibrary.jsx   # Agronomic disease encyclopedia
│           └── AnalyticsDashboard.jsx# Monitoring metrics & trends
└── README.md
```

---

## 🚀 Quickstart: Local Spin-up Instructions

### Prerequisites
- Python 3.10+ (tested on Python 3.14)
- Node.js 18+ & npm (Node v20.18.0 included)

---

### Step 1: Start the Backend Server

Open a terminal and navigate to the `backend` folder:

```powershell
cd plant-health-monitor/backend
python -m pip install -r requirements.txt
python run.py
```

The FastAPI backend will start at:
- **API Server:** `http://127.0.0.1:8000`
- **Interactive Swagger Docs:** `http://127.0.0.1:8000/docs`
- **Health Check:** `http://127.0.0.1:8000/health`

---

### Step 2: Start the Frontend Application

Open a second terminal and navigate to the `frontend` folder:

```powershell
cd plant-health-monitor/frontend
npm install
npm run dev
```

The React + Vite application will start at:
- **Web App:** `http://127.0.0.1:5173`

Open `http://127.0.0.1:5173` in your browser to experience FloraScan AI!

---

## 🧪 Testing & Verification

To verify the backend independently without opening a browser:

```powershell
cd plant-health-monitor/backend
python test_backend.py
```

This automated test script:
1. Validates SQLite schema generation and sample seeding.
2. Checks history retrieval and analytics calculation.
3. Passes test leaf images through the CV detector pipeline and validates lesion bounding boxes, health scores, and treatments.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/v1/predict` | Analyzes uploaded leaf image or sample ID; returns diagnosis, bounding boxes, health score, and remedies |
| `GET` | `/api/v1/history` | Retrieves chronological history of past scans |
| `GET` | `/api/v1/history/{id}` | Retrieves full diagnostic details for a specific past scan |
| `GET` | `/api/v1/health-guide` | Returns complete encyclopedia of plant diseases and treatments |
| `GET` | `/api/v1/samples` | Lists pre-loaded verified leaf specimens for 1-click testing |
| `GET` | `/api/v1/samples/{filename}` | Serves static specimen image file |
| `GET` | `/api/v1/stats` | Aggregated surveillance statistics (total scans, health index, top diseases) |
