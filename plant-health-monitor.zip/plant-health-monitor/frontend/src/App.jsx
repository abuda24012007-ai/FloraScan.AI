import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import ImageUploader from './components/ImageUploader';
import SampleSelector from './components/SampleSelector';
import DiagnosticCard from './components/DiagnosticCard';
import HistoryList from './components/HistoryList';
import DiseaseLibrary from './components/DiseaseLibrary';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import {
  predictWithFile,
  predictWithSample,
  getHistory,
  getScanById,
  getHealthGuide,
  getSamples,
  getAnalyticsStats
} from './services/api';
import { Leaf, AlertCircle, Sparkles, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('scanner');
  const [diagnosticResult, setDiagnosticResult] = useState(null);
  const [currentImage, setCurrentImage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [backendStatus, setBackendStatus] = useState(false);

  // Data states
  const [samples, setSamples] = useState([]);
  const [history, setHistory] = useState([]);
  const [guide, setGuide] = useState([]);
  const [stats, setStats] = useState(null);

  // Initialize data on mount
  useEffect(() => {
    checkHealthAndLoadData();
  }, []);

  const checkHealthAndLoadData = async () => {
    try {
      const [sampleRes, historyRes, guideRes, statsRes] = await Promise.all([
        getSamples().catch(() => []),
        getHistory().catch(() => []),
        getHealthGuide().catch(() => []),
        getAnalyticsStats().catch(() => null),
      ]);
      setSamples(sampleRes);
      setHistory(historyRes);
      setGuide(guideRes);
      setStats(statsRes);
      setBackendStatus(true);
    } catch (err) {
      console.error('Failed to connect to backend service', err);
      setBackendStatus(false);
    }
  };

  const refreshData = async () => {
    try {
      const [historyRes, statsRes] = await Promise.all([
        getHistory().catch(() => []),
        getAnalyticsStats().catch(() => null),
      ]);
      setHistory(historyRes);
      setStats(statsRes);
    } catch (e) {
      console.error('Data refresh error', e);
    }
  };

  // Analyze uploaded photo file
  const handleAnalyzeFile = async (file, previewUrl) => {
    setIsLoading(true);
    setErrorMessage(null);
    setCurrentImage(previewUrl);

    try {
      const result = await predictWithFile(file);
      setDiagnosticResult(result);
      await refreshData();
    } catch (err) {
      console.error(err);
      setErrorMessage(err.message || 'Failed to analyze leaf image.');
    } finally {
      setIsLoading(false);
    }
  };

  // Analyze 1-click test sample
  const handleSelectSample = async (sample) => {
    setIsLoading(true);
    setErrorMessage(null);
    setCurrentImage(`/api/v1/samples/${sample.filename}`);

    try {
      const result = await predictWithSample(sample.sample_id);
      setDiagnosticResult(result);
      await refreshData();
    } catch (err) {
      console.error(err);
      setErrorMessage(err.message || 'Failed to analyze sample leaf.');
    } finally {
      setIsLoading(false);
    }
  };

  // View historical scan
  const handleSelectHistoricalScan = async (scanId) => {
    setIsLoading(true);
    try {
      const fullScan = await getScanById(scanId);
      setDiagnosticResult(fullScan);
      setCurrentImage(fullScan.annotated_image || null);
      setActiveTab('scanner');
    } catch (err) {
      console.error(err);
      setErrorMessage('Could not load selected scan details.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetScan = () => {
    setDiagnosticResult(null);
    setCurrentImage(null);
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        backendStatus={backendStatus}
        onReset={handleResetScan}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {errorMessage && (
          <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-xs font-semibold text-rose-600 hover:text-rose-800"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* TAB 1: SCANNER */}
        {activeTab === 'scanner' && (
          <div className="space-y-8">
            {!diagnosticResult ? (
              <>
                {/* Hero Introduction */}
                <div className="text-center max-w-2xl mx-auto pt-2 pb-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100/70 border border-emerald-200/80 text-emerald-800 text-xs font-semibold mb-3">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    AI Computer Vision Engine Active
                  </div>
                  <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 mb-2">
                    Plant Disease Detection & Health Monitoring
                  </h1>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Upload a plant leaf photograph to instantly detect botanical pathogens, localize necrotic lesions with visual bounding boxes, and generate actionable organic or chemical remedies.
                  </p>
                </div>

                {/* Upload Component */}
                <div className="max-w-3xl mx-auto">
                  <ImageUploader onAnalyze={handleAnalyzeFile} isLoading={isLoading} />
                </div>

                {/* 1-Click Sample Leaf Selector */}
                <div className="max-w-5xl mx-auto">
                  <SampleSelector
                    samples={samples}
                    onSelectSample={handleSelectSample}
                    isLoading={isLoading}
                  />
                </div>
              </>
            ) : (
              /* Diagnostic Report View */
              <DiagnosticCard
                result={diagnosticResult}
                originalImage={currentImage}
                onScanAnother={handleResetScan}
              />
            )}
          </div>
        )}

        {/* TAB 2: HISTORY */}
        {activeTab === 'history' && (
          <HistoryList
            history={history}
            onSelectScan={handleSelectHistoricalScan}
            isLoading={isLoading}
          />
        )}

        {/* TAB 3: CARE & DISEASE LIBRARY */}
        {activeTab === 'library' && (
          <DiseaseLibrary guide={guide} />
        )}

        {/* TAB 4: ANALYTICS DASHBOARD */}
        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            stats={stats}
            onNewScan={() => {
              handleResetScan();
              setActiveTab('scanner');
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200/80 mt-12 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 font-medium text-slate-600">
            <Leaf className="w-4 h-4 text-emerald-600" />
            <span>FloraScan AI • Intelligent Agronomic Diagnostics</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>FastAPI Backend</span>
            <span>•</span>
            <span>React + Tailwind CSS</span>
            <span>•</span>
            <span>Computer Vision & SQLite</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
