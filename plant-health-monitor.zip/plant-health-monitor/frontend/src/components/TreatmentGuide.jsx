import React, { useState } from 'react';
import { Sprout, FlaskConical, ShieldCheck, ThermometerSun, AlertCircle, CheckCircle } from 'lucide-react';

export default function TreatmentGuide({
  organicRemedies = [],
  chemicalRemedies = [],
  preventiveMeasures = [],
  causeBreakdown = '',
  favorableConditions = '',
  isHealthy = false
}) {
  const [activeTab, setActiveTab] = useState('organic');

  const tabs = [
    { id: 'organic', label: 'Organic Care', icon: Sprout, count: organicRemedies.length },
    { id: 'chemical', label: 'Chemical Controls', icon: FlaskConical, count: chemicalRemedies.length },
    { id: 'prevention', label: 'Prevention Protocol', icon: ShieldCheck, count: preventiveMeasures.length },
    { id: 'pathology', label: 'Etiology & Conditions', icon: ThermometerSun },
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
      {/* Tab Navigation */}
      <div className="flex border-b border-slate-200/80 bg-slate-50/70 p-1.5 gap-1 overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200/60 text-slate-600'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="p-5">
        {activeTab === 'organic' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="font-semibold text-emerald-800 flex items-center gap-1.5">
                <Sprout className="w-4 h-4 text-emerald-600" />
                Eco-Friendly & Non-Toxic Remedies
              </span>
              <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-100">
                Safe for pollinators
              </span>
            </div>
            {organicRemedies.map((remedy, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3 rounded-xl bg-emerald-50/40 border border-emerald-100/70 hover:bg-emerald-50/70 transition-colors"
              >
                <div className="mt-0.5 w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 text-xs font-bold">
                  {idx + 1}
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">{remedy}</p>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'chemical' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="font-semibold text-amber-800 flex items-center gap-1.5">
                <FlaskConical className="w-4 h-4 text-amber-600" />
                Targeted Agrochemical Treatments
              </span>
              <span className="text-[11px] bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full border border-amber-200">
                Wear PPE gear
              </span>
            </div>
            {chemicalRemedies.map((remedy, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3 rounded-xl bg-amber-50/30 border border-amber-100/80 hover:bg-amber-50/60 transition-colors"
              >
                <div className="mt-0.5 w-5 h-5 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 text-xs font-bold">
                  {idx + 1}
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">{remedy}</p>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'prevention' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="font-semibold text-blue-800 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Agronomic Cultural Practices
              </span>
              <span className="text-[11px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full border border-blue-200">
                Long-term immunity
              </span>
            </div>
            {preventiveMeasures.map((measure, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3 rounded-xl bg-blue-50/30 border border-blue-100/80 hover:bg-blue-50/60 transition-colors"
              >
                <div className="mt-0.5 w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 text-xs font-bold">
                  {idx + 1}
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">{measure}</p>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'pathology' && (
          <div className="space-y-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-emerald-600" />
                Pathogen Etiology & Biology
              </span>
              <p className="text-slate-600 leading-relaxed">{causeBreakdown || 'Optimal growth state with balanced cellular respiration.'}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
              <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                <ThermometerSun className="w-4 h-4 text-amber-600" />
                Favorable Environmental Microclimate
              </span>
              <p className="text-slate-600 leading-relaxed">{favorableConditions || 'Standard temperate conditions (18-24°C, 50-70% humidity).'}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
