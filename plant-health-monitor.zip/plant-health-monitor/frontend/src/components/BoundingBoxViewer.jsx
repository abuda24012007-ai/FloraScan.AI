import React, { useState } from 'react';
import { Eye, EyeOff, Layers, Scan, Sparkles } from 'lucide-react';

export default function BoundingBoxViewer({ originalImage, annotatedImage, boundingBoxes = [], diseaseName = '' }) {
  const [showBoxes, setShowBoxes] = useState(true);
  const [viewMode, setViewMode] = useState('overlay'); // 'overlay' | 'processed'
  const [activeBoxIndex, setActiveBoxIndex] = useState(null);

  const displayImage = viewMode === 'processed' && annotatedImage ? annotatedImage : originalImage;

  return (
    <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-md flex flex-col">
      {/* Control Toolbar */}
      <div className="bg-slate-950/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2 font-medium">
          <Scan className="w-4 h-4 text-emerald-400" />
          <span>Computer Vision Localization</span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800/60 font-semibold">
            {boundingBoxes.length} Lesion Regions
          </span>
        </div>

        <div className="flex items-center gap-2">
          {annotatedImage && (
            <div className="flex bg-slate-800/80 p-0.5 rounded-lg border border-slate-700">
              <button
                onClick={() => setViewMode('overlay')}
                className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                  viewMode === 'overlay' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                Interactive
              </button>
              <button
                onClick={() => setViewMode('processed')}
                className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                  viewMode === 'processed' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                AI Heatmap
              </button>
            </div>
          )}

          {viewMode === 'overlay' && (
            <button
              onClick={() => setShowBoxes(!showBoxes)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Toggle Bounding Boxes"
            >
              {showBoxes ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5 text-slate-400" />}
              <span>{showBoxes ? 'Boxes On' : 'Boxes Off'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Image Viewport with Bounding Boxes */}
      <div className="relative w-full aspect-square max-h-[460px] bg-slate-950 flex items-center justify-center overflow-hidden group select-none">
        {displayImage ? (
          <div className="relative w-full h-full flex items-center justify-center">
            <img
              src={displayImage}
              alt="Leaf diagnostic analysis"
              className="w-full h-full object-contain"
            />

            {/* Dynamic Interactive SVG / HTML Bounding Boxes (Only in overlay mode) */}
            {viewMode === 'overlay' && showBoxes && boundingBoxes.map((box, idx) => {
              const isSelected = activeBoxIndex === idx;
              const left = `${box.xmin * 100}%`;
              const top = `${box.ymin * 100}%`;
              const width = `${(box.xmax - box.xmin) * 100}%`;
              const height = `${(box.ymax - box.ymin) * 100}%`;

              return (
                <div
                  key={idx}
                  onMouseEnter={() => setActiveBoxIndex(idx)}
                  onMouseLeave={() => setActiveBoxIndex(null)}
                  className={`absolute border-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-yellow-400 bg-yellow-400/25 z-20 scale-[1.02]'
                      : 'border-rose-500 bg-rose-500/15 hover:border-yellow-300 z-10'
                  }`}
                  style={{ left, top, width, height }}
                >
                  {/* Lesion Tag Badge */}
                  <div
                    className={`absolute -top-6 left-0 px-1.5 py-0.5 rounded text-[10px] font-bold whitespace-nowrap shadow-md pointer-events-none transition-transform ${
                      isSelected ? 'bg-yellow-400 text-slate-950 scale-105' : 'bg-slate-900/90 text-white'
                    }`}
                  >
                    #{idx + 1} {box.label} ({Math.round(box.confidence * 100)}%)
                  </div>

                  {/* Corner accents */}
                  <span className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-white pointer-events-none" />
                  <span className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-white pointer-events-none" />
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-slate-500 text-sm">No image available</div>
        )}
      </div>

      {/* Bounding Box legend footer */}
      {boundingBoxes.length > 0 && viewMode === 'overlay' && (
        <div className="bg-slate-950/80 px-4 py-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>Hover over lesions to inspect confidence & classification details</span>
          <span className="font-semibold text-emerald-400">
            {activeBoxIndex !== null ? `Selected Lesion #${activeBoxIndex + 1}` : `${boundingBoxes.length} identified zones`}
          </span>
        </div>
      )}
    </div>
  );
}
