import React from 'react';
import { Leaf, History, BookOpen, BarChart3, Scan, ShieldCheck } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, backendStatus, onReset }) {
  const navItems = [
    { id: 'scanner', label: 'Diagnostic Scanner', icon: Scan },
    { id: 'history', label: 'Scan History', icon: History },
    { id: 'library', label: 'Care & Disease Library', icon: BookOpen },
    { id: 'analytics', label: 'Health Analytics', icon: BarChart3 },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div 
            onClick={() => { setActiveTab('scanner'); onReset?.(); }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-forest-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-slate-900 group-hover:text-emerald-700 transition-colors">
                  FloraScan<span className="text-emerald-600">.AI</span>
                </span>
                <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                  v1.0 Vision
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block">
                Plant Disease Detection & Health Monitoring
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center gap-1 sm:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-800 shadow-xs border border-emerald-200/70 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                  <span className="hidden md:inline">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Status Badge */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200/60 text-xs text-slate-600">
              <span className={`w-2 h-2 rounded-full ${backendStatus ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
              <span className="hidden lg:inline">{backendStatus ? 'AI Engine Online' : 'Connecting...'}</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
