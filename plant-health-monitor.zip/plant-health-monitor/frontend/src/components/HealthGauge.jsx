import React from 'react';
import { Activity, AlertTriangle, CheckCircle2, ShieldAlert } from 'lucide-react';

export default function HealthGauge({ healthScore = 85, severity = 'Moderate', affectedArea = 5.2, lesionCount = 3 }) {
  const radius = 64;
  const strokeWidth = 10;
  const normalizedRadius = radius - strokeWidth / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (Math.max(0, Math.min(100, healthScore)) / 100) * circumference;

  // Determine color and status label
  let colorClass = 'text-emerald-500 stroke-emerald-500';
  let badgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
  let statusText = 'Optimal Health';
  let Icon = CheckCircle2;

  if (healthScore < 50 || severity === 'Severe' || severity === 'Critical') {
    colorClass = 'text-rose-500 stroke-rose-500';
    badgeClass = 'bg-rose-50 text-rose-700 border-rose-200';
    statusText = 'Critical Alert';
    Icon = ShieldAlert;
  } else if (healthScore < 80 || severity === 'Moderate') {
    colorClass = 'text-amber-500 stroke-amber-500';
    badgeClass = 'bg-amber-50 text-amber-700 border-amber-200';
    statusText = 'Moderate Stress';
    Icon = AlertTriangle;
  }

  return (
    <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Health Status Index</h4>
          <p className="text-xs text-slate-500">Multispectral tissue viability score</p>
        </div>
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${badgeClass}`}>
          <Icon className="w-3.5 h-3.5" />
          {severity}
        </span>
      </div>

      <div className="flex items-center justify-around my-2">
        {/* Radial Circular Progress */}
        <div className="relative flex items-center justify-center">
          <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
            {/* Background circle */}
            <circle
              stroke="#e2e8f0"
              fill="transparent"
              strokeWidth={strokeWidth}
              r={normalizedRadius}
              cx={radius}
              cy={radius}
            />
            {/* Animated progress circle */}
            <circle
              className={`${colorClass} transition-all duration-1000 ease-out`}
              fill="transparent"
              strokeWidth={strokeWidth}
              strokeDasharray={circumference + ' ' + circumference}
              style={{ strokeDashoffset }}
              strokeLinecap="round"
              r={normalizedRadius}
              cx={radius}
              cy={radius}
            />
          </svg>
          <div className="absolute flex flex-col items-center justify-center text-center">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900">
              {Math.round(healthScore)}<span className="text-lg font-bold text-slate-400">%</span>
            </span>
            <span className="text-[10px] font-semibold uppercase text-slate-400 tracking-wider">Vitality</span>
          </div>
        </div>

        {/* Metric Details */}
        <div className="space-y-3">
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 min-w-[130px]">
            <span className="text-[11px] text-slate-500 block font-medium">Affected Leaf Area</span>
            <span className="text-base font-bold text-slate-800">{affectedArea}%</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 min-w-[130px]">
            <span className="text-[11px] text-slate-500 block font-medium">Detected Lesions</span>
            <span className="text-base font-bold text-slate-800">{lesionCount} clusters</span>
          </div>
        </div>
      </div>

      {/* Progress Bar comparison */}
      <div className="mt-4 pt-3 border-t border-slate-100">
        <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1.5">
          <span>Photosynthetic Functionality</span>
          <span>{statusText}</span>
        </div>
        <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
          <div
            className={`h-full rounded-full transition-all duration-1000 ${
              healthScore >= 80 ? 'bg-emerald-500' : healthScore >= 50 ? 'bg-amber-500' : 'bg-rose-500'
            }`}
            style={{ width: `${Math.max(5, Math.min(100, healthScore))}%` }}
          />
        </div>
      </div>
    </div>
  );
}
