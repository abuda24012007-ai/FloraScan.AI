import React, { useState } from 'react';
import { BookOpen, Search, Sprout, FlaskConical, ShieldCheck, ThermometerSun, ChevronDown, ChevronUp } from 'lucide-react';

export default function DiseaseLibrary({ guide = [] }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedId, setExpandedId] = useState(null);

  const filteredGuide = guide.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.scientific_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.crops_affected.some((crop) => crop.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-600" />
            Agronomic Pathology & Care Guide
          </h2>
          <p className="text-xs text-slate-500">
            Botanical diagnosis protocols, pathogen etiology, and verified remedies
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search disease, crop, or pathogen..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
          />
        </div>
      </div>

      {/* Disease Cards */}
      <div className="space-y-4">
        {filteredGuide.map((item) => {
          const isExpanded = expandedId === item.disease_id;
          const isHealthy = item.severity_risk === 'None';

          return (
            <div
              key={item.disease_id}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition-all"
            >
              {/* Card Header Bar */}
              <div
                onClick={() => toggleExpand(item.disease_id)}
                className="p-5 flex items-center justify-between cursor-pointer hover:bg-slate-50/70 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-bold text-slate-900">{item.name}</h3>
                    <span className="text-xs italic text-slate-500">({item.scientific_name})</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                      isHealthy
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}>
                      Risk: {item.severity_risk}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Vulnerable hosts: {item.crops_affected.join(', ')}
                  </p>
                </div>

                <div className="flex items-center gap-2 text-slate-400">
                  <span className="text-xs font-medium hidden sm:inline">
                    {isExpanded ? 'Collapse' : 'Details'}
                  </span>
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </div>

              {/* Expanded Details */}
              {isExpanded && (
                <div className="p-5 pt-0 border-t border-slate-100 bg-slate-50/40 space-y-5 animate-in fade-in duration-200">
                  {/* Symptoms & Conditions Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="bg-white p-4 rounded-xl border border-slate-200/70">
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block mb-2">
                        Characteristic Symptoms
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-600">
                        {item.symptoms.map((s, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-emerald-500 font-bold">•</span>
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-white p-4 rounded-xl border border-slate-200/70">
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                        <ThermometerSun className="w-3.5 h-3.5 text-amber-500" />
                        Pathogen & Conditions
                      </span>
                      <p className="text-xs text-slate-600 leading-relaxed mb-2 font-medium">
                        {item.causes}
                      </p>
                      <p className="text-xs text-slate-500 leading-relaxed">
                        <span className="font-semibold text-slate-700">Favorable Climate:</span> {item.favorable_conditions}
                      </p>
                    </div>
                  </div>

                  {/* Organic & Chemical Treatments Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Organic */}
                    <div className="bg-emerald-50/40 p-4 rounded-xl border border-emerald-100">
                      <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                        <Sprout className="w-4 h-4 text-emerald-600" />
                        Organic Treatments
                      </span>
                      <ul className="space-y-2 text-xs text-slate-700">
                        {item.organic_controls.map((ctrl, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                              {idx + 1}
                            </span>
                            <span>{ctrl}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Chemical */}
                    <div className="bg-amber-50/30 p-4 rounded-xl border border-amber-100">
                      <span className="text-xs font-bold text-amber-900 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                        <FlaskConical className="w-4 h-4 text-amber-600" />
                        Chemical Agrochemical Controls
                      </span>
                      <ul className="space-y-2 text-xs text-slate-700">
                        {item.chemical_controls.map((ctrl, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="w-4 h-4 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                              {idx + 1}
                            </span>
                            <span>{ctrl}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Prevention */}
                  <div className="bg-blue-50/30 p-4 rounded-xl border border-blue-100">
                    <span className="text-xs font-bold text-blue-900 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-blue-600" />
                      Preventive Agronomic Measures
                    </span>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
                      {item.prevention.map((prev, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-blue-500 font-bold">•</span>
                          <span>{prev}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
