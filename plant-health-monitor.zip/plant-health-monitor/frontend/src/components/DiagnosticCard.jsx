import React from 'react';
import { ArrowLeft, CheckCircle2, AlertOctagon, Printer, Share2, Tag, Calendar, Sparkles } from 'lucide-react';
import HealthGauge from './HealthGauge';
import BoundingBoxViewer from './BoundingBoxViewer';
import TreatmentGuide from './TreatmentGuide';

export default function DiagnosticCard({ result, originalImage, onScanAnother }) {
  if (!result) return null;

  const isHealthy = result.severity === 'Healthy' || result.health_score >= 85;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
              {result.crop_type}
            </span>
            <span className="text-xs text-slate-500 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              {result.timestamp}
            </span>
            {result.id && (
              <span className="text-xs text-slate-400 font-mono">
                Log #{result.id}
              </span>
            )}
          </div>
          
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-3">
            {result.disease_name}
            {isHealthy ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
            ) : (
              <AlertOctagon className="w-6 h-6 text-amber-500 shrink-0" />
            )}
          </h2>
          <p className="text-sm italic text-slate-500 font-medium">
            {result.scientific_name}
          </p>
        </div>

        {/* Model Confidence Badge */}
        <div className="flex items-center gap-3 self-start md:self-auto">
          <div className="text-right">
            <span className="text-[11px] font-semibold text-slate-500 block uppercase tracking-wider">
              Diagnostic Confidence
            </span>
            <span className="text-xl font-bold text-slate-900">
              {result.confidence}%
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-extrabold text-emerald-700 text-sm">
            AI
          </div>
        </div>
      </div>

      {/* Main Grid: Left Visualizer, Right Health Diagnostics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): Visualizer & Physical Metrics */}
        <div className="lg:col-span-6 space-y-6">
          <BoundingBoxViewer
            originalImage={originalImage}
            annotatedImage={result.annotated_image}
            boundingBoxes={result.bounding_boxes}
            diseaseName={result.disease_name}
          />

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Severity</span>
              <span className="text-sm font-bold text-slate-800">{result.severity}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Necrotic Area</span>
              <span className="text-sm font-bold text-slate-800">{result.affected_area_percentage}%</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs text-center">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Lesion Count</span>
              <span className="text-sm font-bold text-slate-800">{result.lesion_count}</span>
            </div>
          </div>
        </div>

        {/* Right Column (6 cols): Health Score Gauge & Treatment Guide */}
        <div className="lg:col-span-6 space-y-6">
          <HealthGauge
            healthScore={result.health_score}
            severity={result.severity}
            affectedArea={result.affected_area_percentage}
            lesionCount={result.lesion_count}
          />

          <TreatmentGuide
            organicRemedies={result.organic_remedies}
            chemicalRemedies={result.chemical_remedies}
            preventiveMeasures={result.preventive_measures}
            causeBreakdown={result.cause_breakdown}
            favorableConditions={result.favorable_conditions}
            isHealthy={isHealthy}
          />
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200">
        <button
          onClick={onScanAnother}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm shadow-md transition-all w-full sm:w-auto justify-center"
        >
          <ArrowLeft className="w-4 h-4" />
          Scan Another Leaf
        </button>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-sm shadow-2xs transition-all"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            Print Diagnostic Report
          </button>
        </div>
      </div>
    </div>
  );
}
