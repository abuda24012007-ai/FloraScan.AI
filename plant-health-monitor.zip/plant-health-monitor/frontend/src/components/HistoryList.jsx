import React, { useState } from 'react';
import { History, Search, Calendar, ChevronRight, AlertCircle, CheckCircle2, ShieldAlert, Sparkles, Filter } from 'lucide-react';

export default function HistoryList({ history = [], onSelectScan, isLoading }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');

  const filteredHistory = history.filter((item) => {
    const matchesSearch =
      item.disease_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.crop_type.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSeverity =
      severityFilter === 'ALL' ||
      item.severity.toUpperCase() === severityFilter.toUpperCase();

    return matchesSearch && matchesSeverity;
  });

  return (
    <div className="space-y-6">
      {/* Title & Filter Bar */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <History className="w-5 h-5 text-emerald-600" />
            Diagnostic Scan Archive
          </h2>
          <p className="text-xs text-slate-500">
            Chronological records stored in local SQLite database ({history.length} scans recorded)
          </p>
        </div>

        {/* Search & Filter Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search crop or disease..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>

          {/* Severity Dropdown */}
          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white text-slate-700 font-semibold focus:outline-none focus:border-emerald-500"
            >
              <option value="ALL">All Severities</option>
              <option value="HEALTHY">Healthy Only</option>
              <option value="LOW">Low Severity</option>
              <option value="MODERATE">Moderate Severity</option>
              <option value="SEVERE">Severe / Critical</option>
            </select>
          </div>
        </div>
      </div>

      {/* History Grid */}
      {filteredHistory.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs">
          <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h4 className="text-sm font-bold text-slate-700 mb-1">No Scans Found</h4>
          <p className="text-xs text-slate-500">
            {searchTerm || severityFilter !== 'ALL'
              ? 'Try adjusting your search query or filter settings.'
              : 'Scan your first leaf image to see diagnostic logs here.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredHistory.map((scan) => {
            const isHealthy = scan.severity === 'Healthy' || scan.health_score >= 85;
            const isSevere = scan.severity === 'Severe' || scan.severity === 'Critical' || scan.health_score < 50;

            return (
              <div
                key={scan.id}
                onClick={() => onSelectScan(scan.id)}
                className="group bg-white rounded-2xl p-4 border border-slate-200/80 hover:border-emerald-500/60 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    {/* Thumbnail */}
                    <div className="w-14 h-14 rounded-xl bg-slate-100 overflow-hidden shrink-0 border border-slate-100">
                      {scan.thumbnail_data ? (
                        <img
                          src={scan.thumbnail_data}
                          alt={scan.disease_name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-emerald-600 bg-emerald-50">
                          <Sparkles className="w-6 h-6" />
                        </div>
                      )}
                    </div>

                    {/* Health score badge */}
                    <div className="text-right">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${
                        isHealthy
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : isSevere
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {Math.round(scan.health_score)}% Health
                      </span>
                      <span className="block text-[10px] text-slate-400 font-mono mt-1">
                        #{scan.id}
                      </span>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-1">
                    {scan.disease_name}
                  </h3>
                  <p className="text-xs text-slate-500 line-clamp-1 mb-3">
                    {scan.crop_type}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span className="flex items-center gap-1 text-[11px]">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {scan.timestamp.split(' ')[0]}
                  </span>
                  
                  <span className="flex items-center gap-1 font-semibold text-emerald-600 group-hover:translate-x-0.5 transition-transform">
                    <span>Inspect</span>
                    <ChevronRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
