import React from 'react';
import { BarChart3, TrendingUp, CheckCircle2, ShieldAlert, Sparkles, AlertTriangle } from 'lucide-react';

export default function AnalyticsDashboard({ stats, onNewScan }) {
  if (!stats) return null;

  const healthyPct = stats.total_scans > 0 ? Math.round((stats.healthy_scans / stats.total_scans) * 100) : 0;
  const infectedPct = 100 - healthyPct;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-600" />
            Crop Health Analytics & Disease Surveillance
          </h2>
          <p className="text-xs text-slate-500">
            Automated monitoring trends aggregated across all logged plant specimens
          </p>
        </div>

        <button
          onClick={onNewScan}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-all"
        >
          <Sparkles className="w-4 h-4" />
          <span>New Foliage Scan</span>
        </button>
      </div>

      {/* Top 3 Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Card 1: Total Scans */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Leaf Scans</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900 mb-1">
            {stats.total_scans}
          </div>
          <p className="text-xs text-slate-500">Specimens verified by CV engine</p>
        </div>

        {/* Card 2: Average Health Index */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Average Health Score</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-extrabold text-emerald-600 mb-1">
            {stats.avg_health_score}%
          </div>
          <p className="text-xs text-slate-500">Overall vegetation vitality score</p>
        </div>

        {/* Card 3: Healthy vs Infected Ratio */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Infection Rate</span>
            <ShieldAlert className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-3xl font-extrabold text-rose-600 mb-1">
            {infectedPct}%
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>{stats.healthy_scans} healthy</span>
            <span>•</span>
            <span>{stats.infected_scans} infected</span>
          </div>
        </div>
      </div>

      {/* Disease Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            Most Prevalent Diseases Detected
          </h3>

          {stats.top_diseases.length === 0 ? (
            <p className="text-xs text-slate-500">No infected specimens recorded yet.</p>
          ) : (
            <div className="space-y-4">
              {stats.top_diseases.map((d, idx) => {
                const pct = stats.total_scans > 0 ? Math.round((d.count / stats.total_scans) * 100) : 0;
                return (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                      <span>{d.name}</span>
                      <span>{d.count} scans ({pct}%)</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full"
                        style={{ width: `${Math.max(8, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Biosecurity Tips */}
        <div className="bg-gradient-to-br from-emerald-900 to-forest-950 text-white rounded-2xl p-6 shadow-md flex flex-col justify-between">
          <div>
            <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-800 text-emerald-200 mb-3 uppercase tracking-wider">
              Agronomic Intelligence
            </span>
            <h3 className="text-lg font-bold mb-2">Integrated Pest & Disease Management</h3>
            <p className="text-xs text-emerald-100/80 leading-relaxed mb-4">
              Frequent early-stage visual inspection reduces crop yield losses by up to 65%. 
              Always isolate newly purchased transplants for 7 days before introducing them to your greenhouse or main garden beds.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-800/40 border border-emerald-700/50 text-xs text-emerald-200">
            💡 <strong className="text-white">Pro-tip:</strong> Maintain lower leaf spacing and avoid overhead watering to prevent the germination of fungal conidia.
          </div>
        </div>
      </div>
    </div>
  );
}
