import React from 'react';
import { Play, Sparkles, CheckCircle2, AlertTriangle, AlertOctagon } from 'lucide-react';

export default function SampleSelector({ samples = [], onSelectSample, isLoading }) {
  if (!samples || samples.length === 0) return null;

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Quick Test with Pre-Loaded Leaves
          </h3>
          <p className="text-xs text-slate-500">
            Don't have a leaf photo on hand? Select any verified specimen to evaluate detection in real time.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {samples.map((sample) => {
          const isHealthy = sample.condition.toLowerCase().includes('healthy');
          const isCritical = sample.severity === 'Critical';

          return (
            <button
              key={sample.sample_id}
              onClick={() => onSelectSample(sample)}
              disabled={isLoading}
              className="group relative flex flex-col text-left p-2.5 rounded-2xl border border-slate-200/70 hover:border-emerald-500/70 hover:shadow-md bg-slate-50/50 hover:bg-white transition-all text-xs disabled:opacity-50 overflow-hidden"
            >
              {/* Thumbnail Container */}
              <div className="w-full aspect-square rounded-xl bg-slate-100 overflow-hidden mb-2 relative">
                <img
                  src={`/api/v1/samples/${sample.filename}`}
                  alt={sample.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Condition pill overlay */}
                <div className="absolute top-1 right-1">
                  {isHealthy ? (
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white block" />
                  ) : isCritical ? (
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white block" />
                  ) : (
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-white block" />
                  )}
                </div>

                <div className="absolute inset-0 bg-slate-900/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                  <Play className="w-5 h-5 fill-white" />
                </div>
              </div>

              {/* Title & Crop */}
              <span className="font-bold text-slate-800 line-clamp-1 group-hover:text-emerald-700 transition-colors">
                {sample.name}
              </span>
              <span className="text-[10px] text-slate-500 line-clamp-1 mb-1.5">
                {sample.crop.split('(')[0]}
              </span>

              {/* Severity badge */}
              <div className="mt-auto">
                <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                  isHealthy
                    ? 'bg-emerald-100 text-emerald-800'
                    : isCritical
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {sample.condition.split('(')[0].trim()}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
