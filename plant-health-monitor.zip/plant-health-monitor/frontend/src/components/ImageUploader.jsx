import React, { useState, useRef } from 'react';
import { UploadCloud, Image as ImageIcon, Camera, Loader2, Sparkles, X, AlertCircle } from 'lucide-react';

export default function ImageUploader({ onAnalyze, isLoading }) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const fileInputRef = useRef(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const validateAndSetFile = (file) => {
    setErrorMessage(null);
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please upload a valid image file (JPG, PNG, WebP).');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      setErrorMessage('File size exceeds the 15MB limit.');
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleClear = () => {
    setSelectedFile(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setErrorMessage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = () => {
    if (!selectedFile || isLoading) return;
    onAnalyze(selectedFile, previewUrl);
  };

  return (
    <div className="w-full">
      {errorMessage && (
        <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {!previewUrl ? (
        /* Drag & Drop Area */
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center transition-all cursor-pointer ${
            dragActive
              ? 'border-emerald-500 bg-emerald-50/50 scale-[1.01]'
              : 'border-slate-300 hover:border-emerald-500 hover:bg-slate-50/80 bg-white'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleChange}
            className="hidden"
          />

          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-inner">
            <UploadCloud className="w-8 h-8" />
          </div>

          <h3 className="text-lg font-bold text-slate-800 mb-1">
            Drop your plant leaf photo here, or <span className="text-emerald-600 underline">browse</span>
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-6">
            Supports high-resolution camera photos (JPG, PNG, WebP up to 15MB). Position the affected leaf in good lighting for maximum accuracy.
          </p>

          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200 transition-colors">
            <Camera className="w-4 h-4 text-emerald-600" />
            <span>Select from device / camera</span>
          </div>
        </div>
      ) : (
        /* Live Preview Card */
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
              <ImageIcon className="w-4 h-4 text-emerald-600" />
              <span>{selectedFile?.name || 'Selected Leaf Image'}</span>
              <span className="text-slate-400">
                ({(selectedFile?.size / (1024 * 1024)).toFixed(2)} MB)
              </span>
            </div>
            {!isLoading && (
              <button
                onClick={handleClear}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                title="Remove photo"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Preview Image with Scanner Laser Effect when loading */}
          <div className="relative w-full aspect-video max-h-[360px] bg-slate-950 rounded-2xl overflow-hidden flex items-center justify-center mb-6">
            <img
              src={previewUrl}
              alt="Leaf Preview"
              className={`w-full h-full object-contain transition-opacity duration-300 ${
                isLoading ? 'opacity-80' : 'opacity-100'
              }`}
            />

            {isLoading && (
              <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] flex flex-col items-center justify-center text-white">
                {/* Animated Scanner Laser */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#34d399] animate-pulse" />
                
                <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-slate-900/90 border border-emerald-500/40 shadow-2xl">
                  <Loader2 className="w-5 h-5 text-emerald-400 animate-spin" />
                  <div className="text-left">
                    <span className="text-xs font-bold text-slate-100 block">Analyzing Plant Diagnostics...</span>
                    <span className="text-[10px] text-emerald-400 font-mono">Running CV lesion segmentation</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Trigger Button */}
          <div className="flex items-center justify-end gap-3">
            <button
              onClick={handleClear}
              disabled={isLoading}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
            >
              Choose Different Image
            </button>
            <button
              onClick={handleSubmit}
              disabled={isLoading}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all hover:scale-[1.02] disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Multispectral Data...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Diagnose Leaf Health</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
