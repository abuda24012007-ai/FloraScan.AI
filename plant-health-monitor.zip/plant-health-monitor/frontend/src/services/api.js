/**
 * API service for communicating with FastAPI backend.
 */

const API_BASE = '/api/v1';

export async function predictWithFile(file) {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch(`${API_BASE}/predict`, {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Server error (${res.status})`);
  }

  return await res.json();
}

export async function predictWithSample(sampleId) {
  const formData = new FormData();
  formData.append('sample_id', sampleId);

  const res = await fetch(`${API_BASE}/predict`, {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Server error (${res.status})`);
  }

  return await res.json();
}

export async function getHistory(limit = 50, offset = 0) {
  const res = await fetch(`${API_BASE}/history?limit=${limit}&offset=${offset}`);
  if (!res.ok) throw new Error('Failed to load scan history');
  return await res.json();
}

export async function getScanById(scanId) {
  const res = await fetch(`${API_BASE}/history/${scanId}`);
  if (!res.ok) throw new Error(`Failed to load scan #${scanId}`);
  return await res.json();
}

export async function getHealthGuide() {
  const res = await fetch(`${API_BASE}/health-guide`);
  if (!res.ok) throw new Error('Failed to load health guide');
  return await res.json();
}

export async function getSamples() {
  const res = await fetch(`${API_BASE}/samples`);
  if (!res.ok) throw new Error('Failed to load sample leaves');
  return await res.json();
}

export async function getAnalyticsStats() {
  const res = await fetch(`${API_BASE}/stats`);
  if (!res.ok) throw new Error('Failed to load analytics stats');
  return await res.json();
}
