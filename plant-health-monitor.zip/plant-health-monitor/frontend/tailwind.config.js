/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        forest: {
          50: '#f0fdf4',
          100: '#dcfce7',
          200: '#bbf7d0',
          300: '#86efac',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
          800: '#166534',
          900: '#14532d',
          950: '#052e16',
        },
        sage: {
          50: '#f4f7f4',
          100: '#e5ece5',
          200: '#cddbcd',
          300: '#a7c1a8',
          400: '#7ca27f',
          500: '#5e8661',
          600: '#486b4b',
          700: '#3a553c',
          800: '#304432',
          900: '#28382a',
        },
        earth: {
          50: '#fbfaf8',
          100: '#f5f3ef',
          200: '#ece7df',
          300: '#ded4c6',
          400: '#cabb9e',
          500: '#b49e7b',
          600: '#9e8360',
          700: '#80684c',
          800: '#68543f',
          900: '#554536',
        }
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
