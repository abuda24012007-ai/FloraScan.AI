"""Local backend development server launcher."""

import uvicorn

if __name__ == "__main__":
    print("Starting Plant Disease Detection & Health Monitoring Backend API...")
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
