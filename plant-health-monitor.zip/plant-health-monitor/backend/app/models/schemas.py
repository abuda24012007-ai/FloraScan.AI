from pydantic import BaseModel, Field
from typing import List, Optional

class BoundingBox(BaseModel):
    xmin: float = Field(..., description="Normalized min X coordinate (0.0 to 1.0)")
    ymin: float = Field(..., description="Normalized min Y coordinate (0.0 to 1.0)")
    xmax: float = Field(..., description="Normalized max X coordinate (0.0 to 1.0)")
    ymax: float = Field(..., description="Normalized max Y coordinate (0.0 to 1.0)")
    confidence: float = Field(..., description="Detection confidence score for this region")
    label: str = Field(..., description="Lesion / symptom type label")
    severity: str = Field(..., description="Severity classification for this region")

class DiagnosticResult(BaseModel):
    id: Optional[int] = None
    disease_name: str
    scientific_name: str
    crop_type: str
    confidence: float
    health_score: float
    severity: str
    affected_area_percentage: float
    lesion_count: int
    bounding_boxes: List[BoundingBox]
    annotated_image: Optional[str] = None
    cause_breakdown: str
    favorable_conditions: str
    organic_remedies: List[str]
    chemical_remedies: List[str]
    preventive_measures: List[str]
    timestamp: str

class ScanHistoryItem(BaseModel):
    id: int
    timestamp: str
    disease_name: str
    scientific_name: str
    crop_type: str
    confidence: float
    health_score: float
    severity: str
    affected_area_percentage: float
    lesion_count: int
    thumbnail_data: Optional[str] = None

class HealthGuideItem(BaseModel):
    disease_id: str
    name: str
    scientific_name: str
    crops_affected: List[str]
    symptoms: List[str]
    causes: str
    favorable_conditions: str
    organic_controls: List[str]
    chemical_controls: List[str]
    prevention: List[str]
    severity_risk: str

class AnalyticsStats(BaseModel):
    total_scans: int
    healthy_scans: int
    infected_scans: int
    avg_health_score: float
    top_diseases: List[dict]

class SampleLeafInfo(BaseModel):
    sample_id: str
    name: str
    crop: str
    condition: str
    severity: str
    description: str
    filename: str
