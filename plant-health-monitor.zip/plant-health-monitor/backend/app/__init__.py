"""Plant Disease Detection & Health Monitoring Application Package."""
__version__ = "1.0.0"
