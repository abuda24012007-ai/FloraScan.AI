"""FastAPI REST API routes for plant disease detection and health monitoring."""

from pathlib import Path
from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status
from fastapi.responses import FileResponse

from app.core.config import SAMPLES_DIR, settings
from app.core.database import save_scan_result, get_scan_history, get_scan_by_id, get_analytics
from app.models.schemas import DiagnosticResult, ScanHistoryItem, HealthGuideItem, AnalyticsStats, SampleLeafInfo
from app.ml.detector import detector
from app.ml.disease_catalog import DISEASE_CATALOG

router = APIRouter(prefix=settings.API_V1_PREFIX, tags=["Diagnostics & Plant Health"])

SAMPLE_METADATA = [
    {
        "sample_id": "healthy_tomato",
        "name": "Healthy Tomato Leaf",
        "crop": "Tomato (Solanum lycopersicum)",
        "condition": "Healthy Foliage",
        "severity": "None",
        "description": "Vibrant emerald green leaf blade with intact cell margins and uniform chlorophyll distribution.",
        "filename": "healthy_tomato.jpg"
    },
    {
        "sample_id": "early_blight_tomato",
        "name": "Tomato Early Blight",
        "crop": "Tomato (Solanum lycopersicum)",
        "condition": "Early Blight (Alternaria solani)",
        "severity": "Moderate",
        "description": "Characteristic concentric dark brown target-rings encircled by chlorotic yellow halos.",
        "filename": "early_blight_tomato.jpg"
    },
    {
        "sample_id": "late_blight_potato",
        "name": "Potato Late Blight",
        "crop": "Potato (Solanum tuberosum)",
        "condition": "Late Blight (Phytophthora infestans)",
        "severity": "Critical",
        "description": "Expanding irregular water-soaked dark purplish-black necrotic patches with fungal margins.",
        "filename": "late_blight_potato.jpg"
    },
    {
        "sample_id": "leaf_rust_corn",
        "name": "Corn Leaf Rust",
        "crop": "Corn / Maize (Zea mays)",
        "condition": "Common Rust (Puccinia)",
        "severity": "Moderate to High",
        "description": "Powdery reddish-orange pustules erupting through the upper leaf epidermis.",
        "filename": "leaf_rust_corn.jpg"
    },
    {
        "sample_id": "powdery_mildew_squash",
        "name": "Squash Powdery Mildew",
        "crop": "Squash / Cucurbit (Cucurbita)",
        "condition": "Powdery Mildew (Podosphaera xanthii)",
        "severity": "Moderate",
        "description": "White talcum powder-like fungal mycelium patches dusting upper leaf surfaces.",
        "filename": "powdery_mildew_squash.jpg"
    },
    {
        "sample_id": "bacterial_leaf_spot_pepper",
        "name": "Pepper Bacterial Leaf Spot",
        "crop": "Bell Pepper (Capsicum annuum)",
        "condition": "Bacterial Spot (Xanthomonas)",
        "severity": "Moderate to High",
        "description": "Small angular dark necrotic lesions surrounded by translucent yellow halos.",
        "filename": "bacterial_leaf_spot_pepper.jpg"
    }
]


@router.post("/predict", response_model=DiagnosticResult)
async def predict_plant_health(
    file: Optional[UploadFile] = File(None),
    sample_id: Optional[str] = Form(None)
):
    """Accepts an uploaded image file or a predefined sample ID, runs Computer Vision
    diagnostic inference, generates bounding boxes & health metrics, and stores the scan in SQLite.
    """
    image_bytes = None
    filename = "upload.jpg"

    if sample_id:
        # Load predefined sample image
        matched_sample = next((s for s in SAMPLE_METADATA if s["sample_id"] == sample_id), None)
        if not matched_sample:
            raise HTTPException(status_code=400, detail=f"Sample ID '{sample_id}' not found.")
        
        sample_path = SAMPLES_DIR / matched_sample["filename"]
        if not sample_path.exists():
            raise HTTPException(status_code=404, detail="Sample image file not found on disk.")
        
        with open(sample_path, "rb") as f:
            image_bytes = f.read()
        filename = matched_sample["filename"]

    elif file:
        # Validate file format and size
        ext = Path(file.filename).suffix.lower()
        if ext not in settings.ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported file format '{ext}'. Allowed formats: {', '.join(settings.ALLOWED_EXTENSIONS)}"
            )
        
        image_bytes = await file.read()
        if len(image_bytes) > settings.MAX_IMAGE_SIZE_MB * 1024 * 1024:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File exceeds maximum allowed size of {settings.MAX_IMAGE_SIZE_MB}MB."
            )
        filename = file.filename
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No image uploaded. Please provide either a multipart file or a sample_id."
        )

    try:
        # Run Computer Vision inference pipeline
        result = detector.process_and_diagnose(image_bytes, filename=filename)
        # Persist to database
        scan_id = save_scan_result(result)
        result.id = scan_id
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Diagnostic analysis error: {str(e)}")


@router.get("/history", response_model=List[ScanHistoryItem])
def get_history(limit: int = 50, offset: int = 0):
    """Returns chronological scan logs from SQLite database."""
    return get_scan_history(limit=limit, offset=offset)


@router.get("/history/{scan_id}", response_model=DiagnosticResult)
def get_scan_details(scan_id: int):
    """Retrieves full diagnostic details for a specific past scan ID."""
    result = get_scan_by_id(scan_id)
    if not result:
        raise HTTPException(status_code=404, detail=f"Scan record with ID #{scan_id} not found.")
    return result


@router.get("/health-guide", response_model=List[HealthGuideItem])
def get_health_guide():
    """Returns comprehensive agronomic disease and treatment guide for all cataloged plant conditions."""
    guide_items = []
    for key, data in DISEASE_CATALOG.items():
        guide_items.append(HealthGuideItem(
            disease_id=data["id"],
            name=data["name"],
            scientific_name=data["scientific_name"],
            crops_affected=data["crops_affected"],
            symptoms=data["symptoms"],
            causes=data["causes"],
            favorable_conditions=data["favorable_conditions"],
            organic_controls=data["organic_controls"],
            chemical_controls=data["chemical_controls"],
            prevention=data["prevention"],
            severity_risk=data["severity_risk"]
        ))
    return guide_items


@router.get("/samples", response_model=List[SampleLeafInfo])
def get_sample_leaf_list():
    """Returns curated sample plant leaves for 1-click instant testing."""
    return [SampleLeafInfo(**item) for item in SAMPLE_METADATA]


@router.get("/samples/{filename}")
def serve_sample_image(filename: str):
    """Serves static sample leaf image file."""
    path = SAMPLES_DIR / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="Sample image not found.")
    return FileResponse(path, media_type="image/jpeg")


@router.get("/stats", response_model=AnalyticsStats)
def get_analytics_summary():
    """Returns aggregated summary metrics across all historical diagnostic scans."""
    return get_analytics()
