"""Generate realistic sample leaf images for instant 1-click testing in the app."""

import math
import random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

SAMPLES_DIR = Path(__file__).resolve().parent.parent / "samples"
SAMPLES_DIR.mkdir(parents=True, exist_ok=True)


def draw_base_leaf(w=600, h=600, base_color=(45, 135, 55), vein_color=(60, 160, 70)) -> Image.Image:
    """Draws a botanical leaf silhouette with organic natural curvature, petiole, and primary/secondary veins."""
    img = Image.new("RGBA", (w, h), (245, 247, 245, 255))
    draw = ImageDraw.Draw(img)

    # Leaf blade polygon (elliptical teardrop shape)
    pts = []
    cx, cy = w // 2, h // 2 + 30
    rx, ry = 190, 240

    for angle_deg in range(0, 360, 3):
        rad = math.radians(angle_deg)
        # Add natural serration / organic fluctuation
        noise = math.sin(rad * 14) * 6 + math.cos(rad * 7) * 4
        # Pinch at apex (top) and base (bottom)
        if 60 < angle_deg < 120:  # Apex (tip)
            pinch_x = 0.65
            pinch_y = 1.15
        elif 240 < angle_deg < 300:  # Base
            pinch_x = 0.55
            pinch_y = 0.95
        else:
            pinch_x = 1.0
            pinch_y = 1.0

        x = cx + (rx * pinch_x + noise) * math.cos(rad)
        y = cy - (ry * pinch_y + noise) * math.sin(rad)
        pts.append((x, y))

    draw.polygon(pts, fill=(*base_color, 255), outline=(30, 95, 40, 255))

    # Main central vein (midrib)
    draw.line([(cx, cy + ry * 0.95), (cx, cy - ry * 1.1)], fill=(*vein_color, 230), width=6)
    # Petiole stem at bottom
    draw.line([(cx, cy + ry * 0.95), (cx, cy + ry * 1.25)], fill=(80, 110, 50, 255), width=8)

    # Lateral lateral secondary veins branching off midrib
    for v_offset in range(-int(ry * 0.8), int(ry * 0.8), 35):
        vy = cy + v_offset
        # Left vein
        draw.arc([cx - 170, vy - 40, cx, vy + 40], start=280, end=350, fill=(*vein_color, 180), width=3)
        # Right vein
        draw.arc([cx, vy - 40, cx + 170, vy + 40], start=190, end=260, fill=(*vein_color, 180), width=3)

    return img


def generate_all_samples():
    random.seed(42)

    # 1. Healthy Tomato Leaf
    healthy = draw_base_leaf(600, 600, base_color=(38, 148, 52), vein_color=(55, 175, 70))
    healthy = healthy.convert("RGB").filter(ImageFilter.SMOOTH)
    healthy.save(SAMPLES_DIR / "healthy_tomato.jpg", "JPEG", quality=92)

    # 2. Early Blight (Alternaria solani) - Concentric target spots with chlorotic yellow halo
    eb = draw_base_leaf(600, 600, base_color=(42, 138, 48), vein_color=(55, 160, 65))
    eb_draw = ImageDraw.Draw(eb)
    
    spots = [(240, 220, 48), (360, 320, 55), (280, 420, 38), (390, 190, 32)]
    for sx, sy, rad in spots:
        # Chlorotic yellow halo
        eb_draw.ellipse([sx - rad - 20, sy - rad - 20, sx + rad + 20, sy + rad + 20], fill=(215, 195, 45, 190))
        # Concentric rings
        eb_draw.ellipse([sx - rad, sy - rad, sx + rad, sy + rad], fill=(85, 45, 20, 230), outline=(50, 25, 10, 255), width=2)
        eb_draw.ellipse([sx - rad * 0.65, sy - rad * 0.65, sx + rad * 0.65, sy + rad * 0.65], fill=(110, 60, 25, 240), outline=(50, 25, 10, 255), width=2)
        eb_draw.ellipse([sx - rad * 0.35, sy - rad * 0.35, sx + rad * 0.35, sy + rad * 0.35], fill=(45, 20, 8, 255))

    eb = eb.convert("RGB").filter(ImageFilter.SMOOTH_MORE)
    eb.save(SAMPLES_DIR / "early_blight_tomato.jpg", "JPEG", quality=92)

    # 3. Late Blight (Phytophthora infestans) - Large expanding dark water-soaked necrotic patches
    lb = draw_base_leaf(600, 600, base_color=(40, 130, 45), vein_color=(50, 150, 60))
    lb_draw = ImageDraw.Draw(lb)

    # Large irregular water-soaked blotches
    blotches = [
        [(210, 180), (330, 160), (380, 250), (280, 310), (190, 260)],
        [(320, 360), (450, 330), (460, 460), (350, 480), (300, 410)]
    ]
    for b_poly in blotches:
        # Faint pale margin
        lb_draw.polygon(b_poly, fill=(40, 35, 30, 245), outline=(180, 190, 175, 200), width=4)

    lb = lb.convert("RGB").filter(ImageFilter.SMOOTH)
    lb.save(SAMPLES_DIR / "late_blight_potato.jpg", "JPEG", quality=92)

    # 4. Leaf Rust (Puccinia) - Raised reddish-orange pustules
    rust = draw_base_leaf(600, 600, base_color=(48, 140, 50), vein_color=(60, 165, 65))
    rust_draw = ImageDraw.Draw(rust)

    for _ in range(45):
        rx = random.randint(210, 390)
        ry = random.randint(180, 460)
        r_rad = random.randint(4, 9)
        # Small chlorotic speckle
        rust_draw.ellipse([rx - r_rad - 3, ry - r_rad - 3, rx + r_rad + 3, ry + r_rad + 3], fill=(225, 200, 50, 170))
        # Orange/brown pustule center
        rust_draw.ellipse([rx - r_rad, ry - r_rad, rx + r_rad, ry + r_rad], fill=(210, 85, 15, 250), outline=(140, 45, 8, 255))

    rust = rust.convert("RGB").filter(ImageFilter.SMOOTH)
    rust.save(SAMPLES_DIR / "leaf_rust_corn.jpg", "JPEG", quality=92)

    # 5. Powdery Mildew - White/light grey powdery mycelium patches
    mildew = draw_base_leaf(600, 600, base_color=(45, 135, 52), vein_color=(58, 160, 65))
    mildew_draw = ImageDraw.Draw(mildew)

    mildew_patches = [(250, 260, 55), (370, 340, 65), (280, 430, 45), (350, 210, 40)]
    for mx, my, mrad in mildew_patches:
        for _ in range(25):
            ox = mx + random.randint(-mrad, mrad)
            oy = my + random.randint(-mrad, mrad)
            prad = random.randint(8, 22)
            mildew_draw.ellipse([ox - prad, oy - prad, ox + prad, oy + prad], fill=(240, 242, 245, 140))

    mildew = mildew.convert("RGB").filter(ImageFilter.SMOOTH_MORE)
    mildew.save(SAMPLES_DIR / "powdery_mildew_squash.jpg", "JPEG", quality=92)

    # 6. Bacterial Leaf Spot - Small angular dark lesions with bright yellow margins
    spot = draw_base_leaf(600, 600, base_color=(44, 138, 50), vein_color=(56, 160, 65))
    spot_draw = ImageDraw.Draw(spot)

    for _ in range(22):
        bx = random.randint(220, 380)
        by = random.randint(180, 450)
        bw = random.randint(8, 16)
        bh = random.randint(8, 16)
        # Yellow border
        spot_draw.rectangle([bx - 3, by - 3, bx + bw + 3, by + bh + 3], fill=(235, 220, 40, 200))
        # Dark necrotic center
        spot_draw.rectangle([bx, by, bx + bw, by + bh], fill=(45, 28, 15, 255))

    spot = spot.convert("RGB").filter(ImageFilter.SMOOTH)
    spot.save(SAMPLES_DIR / "bacterial_leaf_spot_pepper.jpg", "JPEG", quality=92)

    print("Successfully generated 6 high-fidelity sample leaf images!")


if __name__ == "__main__":
    generate_all_samples()
