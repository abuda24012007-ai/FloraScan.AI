"""Comprehensive plant disease catalog with agronomic diagnostic rules,
pathogen profiles, organic controls, chemical controls, and preventive protocols.
"""

DISEASE_CATALOG = {
    "HEALTHY": {
        "id": "healthy",
        "name": "Healthy Plant Foliage",
        "scientific_name": "Plantae sanitas (Optimal Condition)",
        "crops_affected": ["Tomato", "Potato", "Apple", "Corn", "Grape", "Pepper", "Citrus", "All Crops"],
        "severity_risk": "None",
        "symptoms": [
            "Vibrant, uniform green chlorophyll coloration across whole leaf blade",
            "Intact leaf margins and veins with zero chlorotic discoloration",
            "Zero fungal sporulation, powdery deposits, or necrotic dark spots",
            "Turgid leaf petiole and vigorous cellular structure"
        ],
        "causes": "Plant is thriving under balanced sunlight, proper soil moisture, and optimal soil nutrients (NPK + micronutrients).",
        "favorable_conditions": "Optimal temperature range (18°C - 26°C), relative humidity 50-70%, adequate soil drainage.",
        "organic_controls": [
            "Maintain regular balanced watering schedule; water the root zone, never soak the foliage",
            "Top-dress with organic compost or vermicompost every 4-6 weeks to sustain soil microbiome",
            "Mulch bed with clean wheat straw or woodchips (5cm depth) to retain moisture and prevent soil splash",
            "Foliar spray with diluted seaweed extract (1:500) monthly to reinforce cellular plant immunity"
        ],
        "chemical_controls": [
            "No chemical fungicide or bactericide intervention needed",
            "Optional: Apply balanced water-soluble micronutrient foliar spray (Fe, Mn, Zn, Mg) if soil test indicates minor deficiencies",
            "Monitor weekly for early aphid or mite activity using yellow sticky insect cards"
        ],
        "prevention": [
            "Ensure 45-60cm spacing between individual plants for constant aeration",
            "Practice 3-year crop rotation with non-solanaceous botanical families",
            "Prune bottom 15cm sucker shoots to prevent soil-borne microbial splash"
        ]
    },
    "EARLY_BLIGHT": {
        "id": "early_blight",
        "name": "Early Blight",
        "scientific_name": "Alternaria solani",
        "crops_affected": ["Tomato", "Potato", "Eggplant", "Bell Pepper"],
        "severity_risk": "Moderate to High",
        "symptoms": [
            "Distinct circular to oval brown-black spots with concentric 'target-board' or bullseye rings",
            "Chlorotic yellow halos surrounding necrotic lesion spots",
            "Older lower leaves infected first, gradually progressing upwards towards crown",
            "Leaves turn brittle, yellow, and undergo premature defoliation, exposing fruits to sunscald"
        ],
        "causes": "Fungal pathogen *Alternaria solani*. Overwinters in infected crop debris and solanaceous weeds.",
        "favorable_conditions": "Warm temperatures (24°C - 29°C) combined with frequent rainfall, heavy morning dews, or overhead sprinkler irrigation.",
        "organic_controls": [
            "Remove and incinerate/bag infected lower leaves immediately; do NOT put into home compost",
            "Foliar spray with Copper Octanoate (Copper soap) every 7-10 days upon first symptom spotting",
            "Apply pure Cold-Pressed Neem Oil (5ml/L) emulsified with mild liquid castile soap (2ml/L) as a natural anti-sporulant",
            "Spray bio-fungicide containing *Bacillus subtilis* (Serenade ASO) at 5ml/L weekly"
        ],
        "chemical_controls": [
            "Chlorothalonil 720 SC (apply 2.0 ml per liter of water) for protective barrier coverage",
            "Mancozeb 75% WP (apply 2.5 g per liter) at 7-day spray intervals",
            "Azoxystrobin 23% SC (Amistar) at 1.0 ml per liter for systemic curative action at early onset",
            "Adhere strictly to 7-day pre-harvest withholding interval (PHI) and wear protective mask & gloves"
        ],
        "prevention": [
            "Implement a minimum 3-year crop rotation avoiding all Solanaceae crops (tomatoes, potatoes, eggplants, peppers)",
            "Switch completely to drip irrigation or soaker hoses to keep foliage dry",
            "Stake and trellis vine crops; remove all foliage within 30cm of the soil level",
            "Select resistant cultivars (e.g., Mountain Supreme, Defiant PhR)"
        ]
    },
    "LATE_BLIGHT": {
        "id": "late_blight",
        "name": "Late Blight",
        "scientific_name": "Phytophthora infestans",
        "crops_affected": ["Tomato", "Potato", "Petunia"],
        "severity_risk": "Critical / Severe",
        "symptoms": [
            "Irregular, rapidly enlarging water-soaked pale green lesions turning dark brown to purplish-black",
            "Delicate white cottony/powdery fungal down sporulation on undersides of leaves during humid mornings",
            "Dark brown greasy necrotic streaks along leaf petioles and main stems",
            "Entire foliage collapses and turns into putrid rotting mass within 3-5 days in wet weather"
        ],
        "causes": "Oomycete water-mold pathogen *Phytophthora infestans*. Infamously responsible for the Great Irish Potato Famine.",
        "favorable_conditions": "Cool to moderate temperatures (12°C - 21°C) with persistent relative humidity above 90% and rainy/foggy periods.",
        "organic_controls": [
            "Immediately eradicate and destroy heavily infected plants; enclose in airtight plastic bags before disposal",
            "Spray Bordeaux mixture (1% copper sulfate + hydrated lime) as preventive protective barrier",
            "Apply biological control agent *Trichoderma harzianum* to soil and root zone to suppress oospore germination",
            "Ensure plants are kept under rain covers or high plastic tunnels in regions prone to late blight outbreaks"
        ],
        "chemical_controls": [
            "Metalaxyl-M + Mancozeb (Ridomil Gold MZ 68 WG) at 2.5 g per liter for translaminar protection",
            "Cymoxanil + Famoxadone (Equation Pro) at 0.5 g/L with rapid penetrant stop-action curative efficacy",
            "Dimethomorph 50% WP (Acrobat) at 1.5 g/L alternated with Mandipropamid (Revus) to avoid chemical resistance",
            "Treat entire surrounding crops immediately if late blight is confirmed within 5km radius"
        ],
        "prevention": [
            "Use only certified disease-free seed tubers; inspect transplants rigorously prior to field planting",
            "Destroy all volunteer potato plants and cull piles from previous harvests",
            "Allow maximum airflow by planting rows oriented in the direction of prevailing summer winds",
            "Never work or walk through plant canopies when leaves are wet"
        ]
    },
    "LEAF_RUST": {
        "id": "leaf_rust",
        "name": "Leaf Rust",
        "scientific_name": "Puccinia spp. (Puccinia sorghi / Puccinia triticina)",
        "crops_affected": ["Corn / Maize", "Wheat", "Beans", "Coffee", "Apple (Cedar Apple Rust)", "Roses"],
        "severity_risk": "Moderate to High",
        "symptoms": [
            "Small, raised reddish-orange to cinnamon-brown powdery pustules (uredinia) scattered across both leaf surfaces",
            "Pustules rupture the upper epidermis releasing rusty spore dust when wiped with a finger",
            "Chlorotic pale-yellow ring surrounding each rust pustule",
            "Extensive leaf chlorosis, premature desiccation, and severe reduction in photosynthetic biomass"
        ],
        "causes": "Obligate biotrophic fungal species within the order *Pucciniales*. Spores (urediniospores) travel thousands of kilometers on atmospheric winds.",
        "favorable_conditions": "Moderate temperatures (16°C - 24°C) with at least 6-8 continuous hours of free leaf moisture from dew or fog.",
        "organic_controls": [
            "Apply Micronized Wettable Sulfur (3 g per liter) thoroughly to upper and lower leaf surfaces",
            "Foliar spray with Potassium Bicarbonate (5 g/L) + Horticultural oil (2 ml/L) to desiccate exposed fungal mycelium",
            "Prune off severely infested lower leaf tiers to suppress spore multiplication",
            "Compost tea rich in antagonistic lactic acid bacteria applied weekly during pre-monsoon season"
        ],
        "chemical_controls": [
            "Propiconazole 25% EC (Tilt) at 1.0 ml per liter of water during initial pustule eruption",
            "Tebuconazole 25.9% EC (Folicur) at 1.25 ml per liter for robust curative eradication",
            "Azoxystrobin + Difenoconazole (Amistar Top) at 1.0 ml/L to provide dual preventive and curative control",
            "Rotate chemical fungicide FRAC groups (Group 3 DMI and Group 11 QoI) to suppress resistance"
        ],
        "prevention": [
            "Plant rust-resistant certified hybrid seed varieties featuring specific *Rp* resistance genes",
            "Maintain optimal field weed control; eliminate alternate weed hosts such as wild oxalis and barberry bushes",
            "Avoid excessive late-season nitrogen applications which promote soft, lush tissue vulnerable to rust penetration"
        ]
    },
    "POWDERY_MILDEW": {
        "id": "powdery_mildew",
        "name": "Powdery Mildew",
        "scientific_name": "Podosphaera xanthii / Erysiphe cichoracearum",
        "crops_affected": ["Cucumbers", "Squash", "Pumpkin", "Tomato", "Grapevine", "Apple", "Strawberry"],
        "severity_risk": "Moderate",
        "symptoms": [
            "Distinct powdery, talcum-like white fungal colonies on upper leaf surfaces, petioles, and young stems",
            "Affected leaves curl upwards, buckle, become distorted, and feel dry or leathery",
            "Infected patches coalesce until whole leaf is coated in white fungal mycelium and conidiophores",
            "Premature senescence of foliage leading to low sugar accumulation in fruits and sun damage"
        ],
        "causes": "Airborne fungi in the family *Erysiphaceae*. Unlike most fungi, conidia can germinate without standing liquid water on leaves.",
        "favorable_conditions": "Warm days (20°C - 28°C) with dry conditions followed by humid nights (relative humidity 80-95%) in shady, poorly ventilated locations.",
        "organic_controls": [
            "Milk foliar spray: Mix 1 part fresh cow's milk with 9 parts water; spray in full sunlight (lactoferrin and sunlight produce free radicals toxic to fungi)",
            "Potassium Bicarbonate (3-4 g/L) + Potassium silicate (1 ml/L) alters leaf surface pH to alkaline, halting spore growth",
            "Refined Neem oil (0.5% concentration) sprayed every 7 days in late evening to prevent phytotoxicity",
            "Spray compost tea or *Ampelomyces quisqualis* (natural hyperparasite fungus of powdery mildew)"
        ],
        "chemical_controls": [
            "Myclobutanil 10% WP (Systhane) at 0.5 g/L with translaminar curative action",
            "Trifloxystrobin + Tebuconazole (Nativo 75 WG) at 0.5 g per liter",
            "Sulfur 80% WDG at 2.5 g per liter (do NOT apply if ambient temperature exceeds 32°C)",
            "Apply at 10-14 day intervals until new foliage emerges symptom-free"
        ],
        "prevention": [
            "Position crops in locations receiving at least 6-8 hours of direct, unfiltered solar radiation",
            "Implement trellis cultivation for cucurbits and grapes to keep leaves high off the ground and aerated",
            "Thin out dense center leaves to allow sunlight penetration deep into the canopy",
            "Select powdery mildew resistant (PMR) varieties"
        ]
    },
    "LEAF_SPOT": {
        "id": "leaf_spot",
        "name": "Bacterial Leaf Spot",
        "scientific_name": "Xanthomonas campestris / Xanthomonas perforans",
        "crops_affected": ["Tomato", "Bell Pepper", "Chili", "Strawberry", "Brassicas"],
        "severity_risk": "Moderate to High",
        "symptoms": [
            "Small (2-3 mm) angular, water-soaked dark brown to black lesions bounded by leaf veinlets",
            "Pronounced translucent lemon-yellow chlorotic halo encircling each necrotic spot",
            "Dead spot centers become papery and drop out, creating a characteristic 'shot-hole' perforation",
            "Severe infections cause leaves to turn scorched, curl, and drop off starting from the lower canopy"
        ],
        "causes": "Gram-negative bacterial pathogen *Xanthomonas*. Bacteria enter plants through stomata and microscopic wounding from wind/handling.",
        "favorable_conditions": "High temperatures (25°C - 32°C) combined with high humidity, heavy rainstorms, and mechanical injury from cultivation.",
        "organic_controls": [
            "Spray Copper Hydroxide (Kocide 3000) at 2.0 g/L for protective bactericidal contact action",
            "Apply biological bactericide *Bacillus amyloliquefaciens* (Serenade) at 4-6 ml/L",
            "Disinfect all pruning shears, stakes, and gloves in 70% isopropyl alcohol between every individual plant",
            "Remove diseased leaves during dry afternoon periods only, never when foliage is damp"
        ],
        "chemical_controls": [
            "Fixed Copper bactericide (Copper oxychloride 50 WP at 3.0 g/L) tank-mixed with Mancozeb 75 WP (2.0 g/L) — copper-mancozeb tank mixes release synergistic copper ions effective against resistant bacterial strains",
            "Kasugamycin 3% SL (Kasumin) at 2.0 ml per liter for dedicated systemic antibacterial action",
            "Streptomycin sulfate 9% + Tetracycline hydrochloride 1% (Plantomycin) at 0.5 g/L where permitted by local agricultural regulations"
        ],
        "prevention": [
            "Always purchase hot-water treated or certified disease-free certified hybrid seeds",
            "Eliminate overhead watering completely; utilize beneath-mulch drip line irrigation",
            "Practice a strict 2 to 3-year non-host crop rotation",
            "Apply reflective silver plastic mulch to repel insect vectors and deter moisture accumulation"
        ]
    }
}
