"""SQLite database manager for scan history, diagnostics records, and analytics."""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any

from app.core.config import DB_PATH
from app.models.schemas import DiagnosticResult, ScanHistoryItem, AnalyticsStats, BoundingBox


def get_db_connection() -> sqlite3.Connection:
    """Creates a connection to SQLite database with row factory."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initializes tables and seeds initial history records if empty."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            disease_name TEXT NOT NULL,
            scientific_name TEXT NOT NULL,
            crop_type TEXT NOT NULL,
            confidence REAL NOT NULL,
            health_score REAL NOT NULL,
            severity TEXT NOT NULL,
            affected_area_percentage REAL NOT NULL,
            lesion_count INTEGER NOT NULL,
            bounding_boxes_json TEXT NOT NULL,
            annotated_image TEXT,
            cause_breakdown TEXT,
            favorable_conditions TEXT,
            organic_remedies_json TEXT,
            chemical_remedies_json TEXT,
            preventive_measures_json TEXT
        )
    """)
    conn.commit()

    # Check if empty, seed rich sample history
    cursor.execute("SELECT COUNT(*) FROM scans")
    count = cursor.fetchone()[0]

    if count == 0:
        seed_sample_scans(conn)

    conn.close()


def seed_sample_scans(conn: sqlite3.Connection):
    """Seeds realistic historical scan logs."""
    sample_records = [
        {
            "timestamp": (datetime.now() - timedelta(days=4, hours=2)).strftime("%Y-%m-%d %H:%M:%S"),
            "disease_name": "Healthy Plant Foliage",
            "scientific_name": "Plantae sanitas (Optimal Condition)",
            "crop_type": "Tomato / Solanaceae",
            "confidence": 98.4,
            "health_score": 97.2,
            "severity": "Healthy",
            "affected_area_percentage": 0.3,
            "lesion_count": 0,
            "bounding_boxes_json": json.dumps([]),
            "cause_breakdown": "Vibrant chlorophyll pigmentation, intact leaf margins and vigorous cellular structure.",
            "favorable_conditions": "Optimal temperature (22°C), balanced hydration and adequate soil aeration.",
            "organic_remedies_json": json.dumps([
                "Maintain drip irrigation schedule at root zone",
                "Apply vermicompost tea every 3 weeks",
                "Mulch with clean wheat straw"
            ]),
            "chemical_remedies_json": json.dumps(["No chemical intervention needed."]),
            "preventive_measures_json": json.dumps([
                "Ensure 50cm plant spacing for adequate air circulation",
                "Prune bottom 15cm leaves to prevent soil splash"
            ])
        },
        {
            "timestamp": (datetime.now() - timedelta(days=3, hours=5)).strftime("%Y-%m-%d %H:%M:%S"),
            "disease_name": "Early Blight",
            "scientific_name": "Alternaria solani",
            "crop_type": "Tomato / Potato",
            "confidence": 94.6,
            "health_score": 68.5,
            "severity": "Moderate",
            "affected_area_percentage": 8.4,
            "lesion_count": 4,
            "bounding_boxes_json": json.dumps([
                {"xmin": 0.22, "ymin": 0.35, "xmax": 0.42, "ymax": 0.55, "confidence": 0.95, "label": "Necrotic Target Lesion", "severity": "Medium"},
                {"xmin": 0.58, "ymin": 0.48, "xmax": 0.74, "ymax": 0.65, "confidence": 0.92, "label": "Necrotic Target Lesion", "severity": "Medium"}
            ]),
            "cause_breakdown": "Alternaria solani fungal infection thriving in humid weather and splashing water.",
            "favorable_conditions": "24°C - 28°C with high foliage wetness duration.",
            "organic_remedies_json": json.dumps([
                "Strip infected lower leaves and dispose safely",
                "Spray Copper Octanoate fungicide every 7-10 days",
                "Apply cold-pressed Neem Oil emulsion (5ml/L)"
            ]),
            "chemical_remedies_json": json.dumps([
                "Chlorothalonil 720 SC (2.0 ml/L) for barrier protection",
                "Mancozeb 75 WP (2.5 g/L)"
            ]),
            "preventive_measures_json": json.dumps([
                "Drip irrigation to keep leaves completely dry",
                "Crop rotation away from Solanaceae for 3 seasons"
            ])
        },
        {
            "timestamp": (datetime.now() - timedelta(days=2, hours=1)).strftime("%Y-%m-%d %H:%M:%S"),
            "disease_name": "Leaf Rust",
            "scientific_name": "Puccinia spp.",
            "crop_type": "Corn / Cereal",
            "confidence": 96.1,
            "health_score": 58.2,
            "severity": "Moderate",
            "affected_area_percentage": 14.2,
            "lesion_count": 6,
            "bounding_boxes_json": json.dumps([
                {"xmin": 0.31, "ymin": 0.18, "xmax": 0.48, "ymax": 0.32, "confidence": 0.96, "label": "Rust Pustule Cluster", "severity": "High"},
                {"xmin": 0.52, "ymin": 0.55, "xmax": 0.68, "ymax": 0.72, "confidence": 0.93, "label": "Rust Pustule Cluster", "severity": "Medium"}
            ]),
            "cause_breakdown": "Puccinia fungal spore pustules rupturing epidermis and degrading photosynthesis.",
            "favorable_conditions": "18°C - 24°C with continuous dew formation.",
            "organic_controls": json.dumps([
                "Micronized wettable sulfur (3g/L)",
                "Potassium bicarbonate spray (5g/L)"
            ]),
            "chemical_controls": json.dumps([
                "Propiconazole 25 EC (1.0 ml/L)",
                "Tebuconazole 250 EC"
            ]),
            "prevention": json.dumps([
                "Plant rust-tolerant seed hybrids",
                "Eliminate alternate weed hosts"
            ])
        },
        {
            "timestamp": (datetime.now() - timedelta(hours=14)).strftime("%Y-%m-%d %H:%M:%S"),
            "disease_name": "Powdery Mildew",
            "scientific_name": "Podosphaera xanthii",
            "crop_type": "Cucurbits / Vine Crops",
            "confidence": 93.8,
            "health_score": 64.0,
            "severity": "Moderate",
            "affected_area_percentage": 11.5,
            "lesion_count": 3,
            "bounding_boxes_json": json.dumps([
                {"xmin": 0.15, "ymin": 0.22, "xmax": 0.45, "ymax": 0.48, "confidence": 0.94, "label": "Mildew Mycelium Patch", "severity": "Medium"}
            ]),
            "cause_breakdown": "Erysiphaceae powdery fungal colonies coating upper epidermis.",
            "favorable_conditions": "Warm dry days with humid nights in shaded locations.",
            "organic_remedies_json": json.dumps([
                "Milk spray (1:9 with water) in bright sunlight",
                "Potassium bicarbonate (3g/L)"
            ]),
            "chemical_remedies_json": json.dumps([
                "Myclobutanil 10 WP (0.5g/L)",
                "Sulfur 80 WDG (2.5g/L)"
            ]),
            "preventive_measures_json": json.dumps([
                "Provide full sunlight exposure",
                "Thin canopy for breeze penetration"
            ])
        }
    ]

    cursor = conn.cursor()
    for s in sample_records:
        cursor.execute("""
            INSERT INTO scans (
                timestamp, disease_name, scientific_name, crop_type, confidence,
                health_score, severity, affected_area_percentage, lesion_count,
                bounding_boxes_json, annotated_image, cause_breakdown, favorable_conditions,
                organic_remedies_json, chemical_remedies_json, preventive_measures_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            s["timestamp"], s["disease_name"], s["scientific_name"], s["crop_type"],
            s["confidence"], s["health_score"], s["severity"], s["affected_area_percentage"],
            s["lesion_count"], s["bounding_boxes_json"], None,
            s.get("cause_breakdown", ""), s.get("favorable_conditions", ""),
            s.get("organic_remedies_json", "[]"), s.get("chemical_remedies_json", "[]"),
            s.get("preventive_measures_json", "[]")
        ))
    conn.commit()


def save_scan_result(result: DiagnosticResult) -> int:
    """Saves a new diagnostic scan result into SQLite and returns the inserted scan ID."""
    conn = get_db_connection()
    cursor = conn.cursor()

    boxes_json = json.dumps([b.dict() for b in result.bounding_boxes])
    org_json = json.dumps(result.organic_remedies)
    chem_json = json.dumps(result.chemical_remedies)
    prev_json = json.dumps(result.preventive_measures)

    cursor.execute("""
        INSERT INTO scans (
            timestamp, disease_name, scientific_name, crop_type, confidence,
            health_score, severity, affected_area_percentage, lesion_count,
            bounding_boxes_json, annotated_image, cause_breakdown, favorable_conditions,
            organic_remedies_json, chemical_remedies_json, preventive_measures_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        result.timestamp,
        result.disease_name,
        result.scientific_name,
        result.crop_type,
        result.confidence,
        result.health_score,
        result.severity,
        result.affected_area_percentage,
        result.lesion_count,
        boxes_json,
        result.annotated_image,
        result.cause_breakdown,
        result.favorable_conditions,
        org_json,
        chem_json,
        prev_json
    ))
    conn.commit()
    inserted_id = cursor.lastrowid
    conn.close()
    return inserted_id


def get_scan_history(limit: int = 50, offset: int = 0) -> List[ScanHistoryItem]:
    """Retrieves chronological scan history records."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, timestamp, disease_name, scientific_name, crop_type,
               confidence, health_score, severity, affected_area_percentage,
               lesion_count, annotated_image
        FROM scans
        ORDER BY id DESC
        LIMIT ? OFFSET ?
    """, (limit, offset))
    rows = cursor.fetchall()
    conn.close()

    history = []
    for r in rows:
        history.append(ScanHistoryItem(
            id=r["id"],
            timestamp=r["timestamp"],
            disease_name=r["disease_name"],
            scientific_name=r["scientific_name"],
            crop_type=r["crop_type"],
            confidence=r["confidence"],
            health_score=r["health_score"],
            severity=r["severity"],
            affected_area_percentage=r["affected_area_percentage"],
            lesion_count=r["lesion_count"],
            thumbnail_data=r["annotated_image"]
        ))
    return history


def get_scan_by_id(scan_id: int) -> Optional[DiagnosticResult]:
    """Retrieves full diagnostic result record by scan ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
    r = cursor.fetchone()
    conn.close()

    if not r:
        return None

    boxes_raw = json.loads(r["bounding_boxes_json"])
    boxes = [BoundingBox(**b) for b in boxes_raw]

    return DiagnosticResult(
        id=r["id"],
        disease_name=r["disease_name"],
        scientific_name=r["scientific_name"],
        crop_type=r["crop_type"],
        confidence=r["confidence"],
        health_score=r["health_score"],
        severity=r["severity"],
        affected_area_percentage=r["affected_area_percentage"],
        lesion_count=r["lesion_count"],
        bounding_boxes=boxes,
        annotated_image=r["annotated_image"],
        cause_breakdown=r["cause_breakdown"] or "",
        favorable_conditions=r["favorable_conditions"] or "",
        organic_remedies=json.loads(r["organic_remedies_json"] or "[]"),
        chemical_remedies=json.loads(r["chemical_remedies_json"] or "[]"),
        preventive_measures=json.loads(r["preventive_measures_json"] or "[]"),
        timestamp=r["timestamp"]
    )


def get_analytics() -> AnalyticsStats:
    """Calculates overall monitoring statistics across all recorded scans."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM scans")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scans WHERE severity = 'Healthy'")
    healthy = cursor.fetchone()[0]
    infected = total - healthy

    cursor.execute("SELECT AVG(health_score) FROM scans")
    avg_score_raw = cursor.fetchone()[0]
    avg_health_score = round(avg_score_raw, 1) if avg_score_raw else 85.0

    cursor.execute("""
        SELECT disease_name, COUNT(*) as count
        FROM scans
        WHERE disease_name != 'Healthy Plant Foliage'
        GROUP BY disease_name
        ORDER BY count DESC
        LIMIT 5
    """)
    top_rows = cursor.fetchall()
    top_diseases = [{"name": r["disease_name"], "count": r["count"]} for r in top_rows]

    conn.close()

    return AnalyticsStats(
        total_scans=total,
        healthy_scans=healthy,
        infected_scans=infected,
        avg_health_score=avg_health_score,
        top_diseases=top_diseases
    )
