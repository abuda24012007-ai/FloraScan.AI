"""FastAPI application entrypoint for Plant Disease Detection and Health Monitoring."""

from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from app.core.config import settings, SAMPLES_DIR, BASE_DIR
from app.core.database import init_db
from app.api.routes import router

FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist" if (BASE_DIR.parent / "frontend" / "dist").exists() else BASE_DIR / "frontend" / "dist"


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initialize database tables and seed samples
    init_db()
    yield
    # Shutdown logic if any


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="End-to-end Plant Health Monitoring & Computer Vision Disease Diagnostics API",
    lifespan=lifespan
)

# Enable CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router)

# Mount samples directory for direct static access
app.mount("/static/samples", StaticFiles(directory=str(SAMPLES_DIR)), name="samples")

# Mount frontend assets if dist exists
if FRONTEND_DIST.exists() and (FRONTEND_DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="frontend-assets")


@app.get("/")
def root():
    # If the production build exists, serve the FloraScan AI Web Application directly!
    index_html = FRONTEND_DIST / "index.html"
    if index_html.exists():
        return FileResponse(index_html)

    return {
        "status": "online",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "endpoints": {
            "predict": f"{settings.API_V1_PREFIX}/predict",
            "history": f"{settings.API_V1_PREFIX}/history",
            "health_guide": f"{settings.API_V1_PREFIX}/health-guide",
            "samples": f"{settings.API_V1_PREFIX}/samples",
            "stats": f"{settings.API_V1_PREFIX}/stats"
        }
    }


@app.get("/api-status")
def api_status():
    return {
        "status": "online",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "endpoints": {
            "predict": f"{settings.API_V1_PREFIX}/predict",
            "history": f"{settings.API_V1_PREFIX}/history",
            "health_guide": f"{settings.API_V1_PREFIX}/health-guide",
            "samples": f"{settings.API_V1_PREFIX}/samples",
            "stats": f"{settings.API_V1_PREFIX}/stats"
        }
    }


@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "plant-health-detector"}
