"""Test script to verify all backend routes and CV detector directly."""

import asyncio
from pathlib import Path
from app.core.database import init_db, get_scan_history, get_analytics
from app.ml.detector import detector
from app.core.config import SAMPLES_DIR

def run_tests():
    print("1. Initializing database...")
    init_db()
    
    print("2. Testing scan history retrieval...")
    history = get_scan_history(limit=5)
    print(f"   Retrieved {len(history)} history records.")
    assert len(history) > 0, "History should have seeded records"

    print("3. Testing analytics stats...")
    stats = get_analytics()
    print(f"   Total scans: {stats.total_scans}, Avg Health: {stats.avg_health_score}")
    assert stats.total_scans >= 4, "Total scans should be >= 4"

    print("4. Testing CV diagnostic detector with sample image...")
    sample_file = SAMPLES_DIR / "early_blight_tomato.jpg"
    assert sample_file.exists(), f"Sample file {sample_file} must exist"
    
    with open(sample_file, "rb") as f:
        img_bytes = f.read()

    res = detector.process_and_diagnose(img_bytes, filename="early_blight_tomato.jpg")
    print(f"   Detected Disease: {res.disease_name}")
    print(f"   Confidence: {res.confidence}%")
    print(f"   Health Score: {res.health_score}% ({res.severity})")
    print(f"   Affected Area: {res.affected_area_percentage}%")
    print(f"   Lesion Count: {res.lesion_count} bounding boxes")
    print(f"   Organic Remedies count: {len(res.organic_remedies)}")
    print(f"   Chemical Remedies count: {len(res.chemical_remedies)}")
    assert res.health_score > 0, "Health score must be positive"
    assert len(res.bounding_boxes) > 0, "Bounding boxes should be detected"
    assert res.annotated_image.startswith("data:image/jpeg;base64,"), "Annotated image should be valid base64 data URI"

    print("\nALL BACKEND TESTS PASSED!")

if __name__ == "__main__":
    run_tests()
